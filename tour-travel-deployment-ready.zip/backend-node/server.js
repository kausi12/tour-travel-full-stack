const express = require("express");
const mongoose = require("mongoose");
require("dotenv").config();

const app = express();
app.use(express.json());

mongoose.connect(process.env.MONGO_URI);

const Booking = mongoose.model("Booking", {
  name: String,
  place: String
});

app.post("/book", async (req, res) => {
  await Booking.create(req.body);
  res.send("Booking Successful");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log("Backend running"));
