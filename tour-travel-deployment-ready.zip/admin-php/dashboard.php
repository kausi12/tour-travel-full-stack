<?php
include "config.php";
echo "Live Admin Panel";
?>