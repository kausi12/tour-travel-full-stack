Deployment-Ready Tour & Travel Booking Website

STACK:
Frontend: Next.js (React)
Backend: Node.js (Express)
Database: MongoDB Atlas
Admin: PHP + MySQL

DEPLOYMENT:
- Frontend: Vercel
- Backend: Render
- DB: MongoDB Atlas
- Admin: 000webhost

ENV (Backend):
MONGO_URI=your_mongodb_atlas_url
PORT=5000

ENV (Frontend):
NEXT_PUBLIC_API_URL=https://your-backend-url

AI-generated project. Ready for public use.
