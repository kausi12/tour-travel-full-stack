export default function Home() {
  return (
    <div>
      <h1>Tour & Travel Booking</h1>
      <a href="/booking">Book Now</a>
    </div>
  );
}
