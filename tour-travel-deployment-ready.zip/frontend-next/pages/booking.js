export default function Booking() {
  async function book() {
    await fetch(process.env.NEXT_PUBLIC_API_URL + "/book", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "User", place: "Goa" })
    });
    alert("Booking Successful");
  }
  return <button onClick={book}>Confirm Booking</button>;
}
